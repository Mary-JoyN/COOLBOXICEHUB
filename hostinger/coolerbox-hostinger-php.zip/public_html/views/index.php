<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#0b2b5b">
  <title>The CoolerBox Ice Hub | Ice, Bottled Water & Refills in Ongwediva</title>
  <meta name="description"
    content="Trusted supplier of purified gourmet ice, ice blocks, crushed ice, bottled water (500ml, 1.5L, 5L) and water refills at Makalani Mall, Ongwediva.">
  <link rel="icon" type="image/jpeg" href="/assets/logo-symbol-blue.jpeg">
  <link rel="preconnect" href="https://maps.google.com">
  <link rel="preconnect" href="https://maps.gstatic.com" crossorigin>
  <link rel="dns-prefetch" href="https://maps.google.com">
  <link rel="stylesheet" href="/ice-company.css">
</head>

<body>
  <!-- Top Bar -->
  <div class="site-top-bar">
    <div class="site-top-inner">
      <div class="top-bar-location">
        <span>📍 Makalani Mall · Ongwediva, Namibia</span>
      </div>
      <div class="top-bar-contact">
        <a href="mailto:info@coolerboxicehub.com">✉ info@coolerboxicehub.com</a>
        <a href="https://wa.me/264852485426" target="_blank" rel="noopener">💬 WhatsApp +264 85 248 5426</a>
      </div>
    </div>
  </div>

  <!-- Header Navigation -->
  <header class="site-header">
    <div class="site-nav-container">
      <a class="site-brand" href="/" aria-label="CoolerBox Ice Hub Home">
        <img src="/assets/logo-primary.jpeg" alt="The CoolerBox — Ice, Water, Refreshment">
      </a>
      <ul class="site-nav-menu">
        <li><a class="site-nav-link active" href="/">Home</a></li>
        <li><a class="site-nav-link" href="/products">Products</a></li>
        <li><a class="site-nav-link" href="/services">Business &amp; Events</a></li>
        <li><a class="site-nav-link" href="/contact">Contact</a></li>
        <li><a class="site-nav-link" href="/order?product=ice">Express</a></li>
      </ul>
      <a class="btn-header-order" href="/order">Order / Quote ↗</a>
      <button class="mobile-menu-toggle" id="menu-btn" aria-label="Toggle navigation" aria-expanded="false">☰</button>
    </div>
    <div class="mobile-drawer" id="mobile-drawer">
      <a class="active" href="/">Home</a>
      <a href="/products">Products</a>
      <a href="/services">Business &amp; Events</a>
      <a href="/contact">Contact</a>
      <a href="/order?product=ice">Express</a>
      <a href="/order" style="color:var(--cb-cyan);font-weight:700">Order / Quote ↗</a>
    </div>
  </header>

  <!-- Ice Cubes Dropping in Water Hero Section -->
  <section class="hero-video-banner">
    <div class="hero-video-overlay" style="z-index:1"></div>
    <canvas id="hero-ice-canvas" class="hero-video-bg" style="opacity:0.95;z-index:2;pointer-events:none" aria-hidden="true"></canvas>
    <div class="hero-content-wrap">
      <span class="hero-pill-tag">ICE · BOTTLED WATER · WATER REFILLS</span>
      <h1>
        Ice. Water.
        <em>Stay Cooler.</em>
      </h1>
      <p class="hero-subtitle">
        Your local source of ice, bottled water and water refills in Ongwediva. From everyday purchases to bulk orders, The CoolerBox serves homes, businesses and events.
      </p>
      <div class="hero-cta-group">
        <a class="btn-hero-primary" href="/products">View Our Products ↗</a>        <a class="btn-hero-outline" href="/contact">Send an Enquiry ✉</a>
      </div>
    </div>
  </section>

  <!-- Main Content -->
  <main class="content-section">
    <!-- Quality & About The CoolerBox Ice Hub cc -->
    <div id="about" style="background:#ffffff;border:1px solid var(--cb-border);border-radius:var(--cb-radius-md);padding:44px 40px;margin-bottom:60px;box-shadow:var(--cb-shadow-sm)">
      <div class="story-hub-grid">
        <div>
          <span class="section-pre-title">ABOUT THE COOLERBOX ICE HUB CC</span>
          <h2 style="font-family:var(--cb-font-heading);font-size:clamp(26px, 3.2vw, 36px);color:var(--cb-navy);margin:0 0 16px;line-height:1.25">
            Your Neighbourhood Ice &amp; Refreshment Hub in Ongwediva.
          </h2>
          <p style="color:var(--cb-text-muted);font-size:16px;line-height:1.7;margin:0 0 14px">
            <strong>Vision:</strong> To be the ice and water supplier northern Namibia can rely on: always in stock, always clean, always on time.
          </p>
          <p style="color:var(--cb-text-muted);font-size:16px;line-height:1.7;margin:0 0 14px">
            <strong>Mission:</strong> To produce safe ice and drinking water through controlled, efficient processes, deliver them dependably, and build skilled, paid jobs for young people in Ongwediva.
          </p>
          <p style="color:var(--cb-text-muted);font-size:15px;line-height:1.65;margin:0 0 22px">
            <strong>Quality &amp; Operations:</strong> Consistency, fair pricing, quality, convenience and credibility guide our daily operations at Shop 14, Makalani Mall—backed by clean handling and hygienic packaging.
          </p>
          <div style="display:flex;flex-wrap:wrap;gap:14px">
            <a class="btn-hero-primary" href="/products" style="padding:12px 24px;font-size:14px">View Product Catalogue ↗</a>
            <a class="btn-hero-outline" href="/services" style="color:var(--cb-navy);background:var(--cb-ice-white);border-color:#b8d3ea;padding:12px 24px;font-size:14px">Business &amp; Event Supply ↗</a>
          </div>
        </div>
        <div class="story-hub-image-wrap" style="border-radius:var(--cb-radius-md);overflow:hidden;box-shadow:0 10px 26px rgba(0,79,132,0.12);border:1px solid var(--cb-border)">
          <img src="/assets/coolerbox-cool-starts-here.jpg" alt="The CoolerBox Ice Hub cc storefront display" style="width:100%;height:100%;object-fit:cover;max-height:340px;display:block" loading="lazy">
        </div>
      </div>

      <!-- 5 Core Pillars / Values -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:14px;margin-top:32px;padding-top:28px;border-top:1px solid var(--cb-border)">
        <div style="background:var(--cb-ice-white);border:1px solid var(--cb-border);border-radius:12px;padding:16px">
          <strong style="display:block;font-size:15.5px;color:var(--cb-navy);margin-bottom:5px">Consistency</strong>
          <p style="margin:0;font-size:13.5px;line-height:1.5;color:var(--cb-text-muted)">Planned daily production, so stock never runs out</p>
        </div>
        <div style="background:var(--cb-ice-white);border:1px solid var(--cb-border);border-radius:12px;padding:16px">
          <strong style="display:block;font-size:15.5px;color:var(--cb-navy);margin-bottom:5px">Price</strong>
          <p style="margin:0;font-size:13.5px;line-height:1.5;color:var(--cb-text-muted)">Fair, fixed prices and N$1.50/L refills</p>
        </div>
        <div style="background:var(--cb-ice-white);border:1px solid var(--cb-border);border-radius:12px;padding:16px">
          <strong style="display:block;font-size:15.5px;color:var(--cb-navy);margin-bottom:5px">Quality</strong>
          <p style="margin:0;font-size:13.5px;line-height:1.5;color:var(--cb-text-muted)">Treated, tested water; sealed, dated bags</p>
        </div>
        <div style="background:var(--cb-ice-white);border:1px solid var(--cb-border);border-radius:12px;padding:16px">
          <strong style="display:block;font-size:15.5px;color:var(--cb-navy);margin-bottom:5px">Convenience</strong>
          <p style="margin:0;font-size:13.5px;line-height:1.5;color:var(--cb-text-muted)">Two shops, partner freezers, WhatsApp and delivery</p>
        </div>
        <div style="background:var(--cb-ice-white);border:1px solid var(--cb-border);border-radius:12px;padding:16px">
          <strong style="display:block;font-size:15.5px;color:var(--cb-navy);margin-bottom:5px">Credibility</strong>
          <p style="margin:0;font-size:13.5px;line-height:1.5;color:var(--cb-text-muted)">Registered, compliant and run by a qualified artisan</p>
        </div>
      </div>
    </div>

    <!-- Location & Google Map Section (Makalani Mall, Ongwediva) -->
    <div style="background:#ffffff;border:1px solid var(--cb-border);border-radius:var(--cb-radius-md);padding:44px 40px;margin-bottom:60px;box-shadow:var(--cb-shadow-sm)">
      <div class="hub-map-grid">
        <div>
          <span class="section-pre-title">VISIT OUR HUB</span>
          <h2 style="font-family:var(--cb-font-heading);font-size:clamp(26px, 3.2vw, 36px);color:var(--cb-navy);margin:0 0 16px;line-height:1.25">
            Find Your Cool at Makalani Mall, Ongwediva.
          </h2>
          <p style="color:var(--cb-text-muted);font-size:16px;line-height:1.7;margin:0 0 22px">
            Drop by our shop to collect crisp purified ice cubes, block ice, or chilled bottled water. Convenient parking and swift loading make stock-ups fast and hassle-free.
          </p>

          <div style="display:flex;flex-direction:column;gap:14px;margin-bottom:26px">
            <div style="display:flex;align-items:flex-start;gap:12px">
              <span style="font-size:20px;line-height:1">📍</span>
              <div>
                <strong style="color:var(--cb-navy);font-size:15px;display:block">Physical Location</strong>
                <span style="color:var(--cb-text-muted);font-size:14px">Shop 14, Makalani Mall, Main Road, Ongwediva, Namibia</span>
              </div>
            </div>
            <div style="display:flex;align-items:flex-start;gap:12px">
              <span style="font-size:20px;line-height:1">⏰</span>
              <div>
                <strong style="color:var(--cb-navy);font-size:15px;display:block">Trading Hours</strong>
                <span style="color:var(--cb-text-muted);font-size:14px">Monday – Thursday: 09:00 – 19:00 &nbsp;|&nbsp; Friday – Saturday: 09:00 – 20:00 &nbsp;|&nbsp; Sunday: 10:00 – 18:00</span>
              </div>
            </div>
            <div style="display:flex;align-items:flex-start;gap:12px">
              <span style="font-size:20px;line-height:1">✉️</span>
              <div>
                <strong style="color:var(--cb-navy);font-size:15px;display:block">Orders & Enquiries</strong>
                <span style="color:var(--cb-text-muted);font-size:14px"><a href="mailto:info@coolerboxicehub.com" style="color:var(--cb-navy);text-decoration:none;font-weight:600">info@coolerboxicehub.com</a> &nbsp;•&nbsp; WhatsApp: +264 85 248 5426</span>
              </div>
            </div>
          </div>

          <div style="display:flex;flex-wrap:wrap;gap:14px">
            <a class="btn-hero-primary" href="https://maps.google.com/?q=Makalani+Mall,+Ongwediva,+Namibia" target="_blank" rel="noopener noreferrer" style="padding:12px 24px;font-size:14px">Get Directions ↗</a>
            <a class="btn-hero-outline" href="/contact" style="color:var(--cb-navy);background:var(--cb-ice-white);border-color:#b8d3ea;padding:12px 24px;font-size:14px">Send an Enquiry ✉</a>
          </div>
        </div>

        <div id="hub-map-box" style="border-radius:var(--cb-radius-md);overflow:hidden;box-shadow:0 8px 24px rgba(0,79,132,0.12);border:1px solid var(--cb-border);background:#e8f1f8;min-height:320px;position:relative;display:flex;align-items:center;justify-content:center">
          <div id="hub-map-fallback" style="position:absolute;inset:0;padding:24px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:var(--cb-navy);z-index:0">
            <strong style="font-size:16px;margin-bottom:6px">📍 Shop 14, Makalani Mall, Ongwediva</strong>
            <span id="hub-map-status" style="font-size:13.5px;color:var(--cb-text-muted);margin-bottom:14px">Loading Makalani Mall map…</span>
            <a class="btn-hero-primary" href="https://maps.google.com/?q=Makalani+Mall,+Ongwediva,+Namibia" target="_blank" rel="noopener noreferrer" style="padding:10px 20px;font-size:14px">Get Directions ↗</a>
          </div>
          <iframe
            id="hub-map-iframe"
            src="https://maps.google.com/maps?q=-17.7783,15.7646+(Makalani+Mall,+Ongwediva,+Namibia)&amp;t=&amp;z=15&amp;ie=UTF8&amp;iwloc=&amp;output=embed"
            width="100%"
            height="360"
            style="border:0;display:block;position:relative;z-index:1"
            allowfullscreen=""
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
            title="The CoolerBox Ice Hub location map at Makalani Mall, Ongwediva">
          </iframe>
        </div>
      </div>
    </div>

    <!-- Section Preview: Business & Event Supply -->
    <div style="background:linear-gradient(135deg, var(--cb-navy) 0%, var(--cb-navy-deep) 100%);border-radius:var(--cb-radius-md);padding:46px 40px;color:#ffffff;margin-bottom:60px">
      <div style="max-width:820px">
        <span class="hero-pill-tag">BUSINESS & EVENT SUPPLY</span>
        <h2 style="font-family:var(--cb-font-heading);font-size:clamp(26px, 3.2vw, 36px);margin:0 0 16px;line-height:1.25">
          Ice & Water Supply for Businesses and Events
        </h2>
        <p style="color:#d5e7f5;font-size:16.5px;line-height:1.65;margin:0 0 26px">
          Planning an event or looking for a regular ice and water supplier? The CoolerBox caters for retailers, bars, restaurants, accommodation establishments and event organisers. Contact us to discuss product options, quantities and supply arrangements for your business or occasion.
        </p>
        <div style="display:flex;flex-wrap:wrap;gap:14px">
          <a class="btn-hero-primary" href="/services" style="padding:12px 26px;font-size:14px">Explore Business & Event Supply ↗</a>
          <a class="btn-hero-outline" href="/order" style="padding:12px 26px;font-size:14px">Request a Quote ↗</a>
        </div>
      </div>
    </div>

    <!-- Closing Call to Action Banner -->
    <div style="background:#ffffff;border:1px solid var(--cb-border);border-radius:var(--cb-radius-md);padding:44px 36px;text-align:center;box-shadow:var(--cb-shadow-sm)">
      <h2 style="font-family:var(--cb-font-heading);font-size:30px;color:var(--cb-navy);margin:0 0 12px">
        From Ice to Bottled Water, We've Got You Covered.
      </h2>
      <p style="color:var(--cb-text-muted);font-size:16px;max-width:640px;margin:0 auto 28px;line-height:1.6">
        Ready to place an order, request an official quotation, or discuss commercial partnership? Message our team directly at <strong>info@coolerboxicehub.com</strong> or WhatsApp <strong>+264 85 248 5426</strong>.
      </p>
      <div style="display:flex;justify-content:center;flex-wrap:wrap;gap:14px">
        <a class="btn-hero-primary" href="/order">Order Now / Estimate ↗</a>
        <a class="btn-hero-outline" href="/contact" style="color:var(--cb-navy);background:var(--cb-ice-white);border-color:#b5d1e8">Send an Enquiry ✉</a>
      </div>
    </div>
  </main>

  <!-- Global Footer -->
  <footer class="site-footer-new">
    <div class="footer-inner-grid">
      <div class="footer-col-brand">
        <img src="/assets/logo-primary.jpeg" alt="The CoolerBox Ice Hub">
        <p>Pure Ice. Everyday Water. Reliable Supply across Ongwediva & Northern Namibia.</p>
        <p style="margin-top:12px;font-size:13px;color:#8dafc9">📍 Shop 14, Makalani Mall, Ongwediva</p>
      </div>
      <div class="footer-col">
        <h4>Navigation</h4>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/products">Products</a></li>
          <li><a href="/services">Business & Events</a></li>
          <li></li>
          <li><a href="/order">Order Now</a></li>
          <li><a href="/contact">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Help & Info</h4>
        <ul>
          <li><a href="/questions">Questions & Answers</a></li>
          <li><a href="/reviews">Customer Reviews</a></li>
          <li><a href="/privacy">Privacy Notice</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Direct Contact</h4>
        <ul>
          <li><a href="mailto:info@coolerboxicehub.com">✉ info@coolerboxicehub.com</a></li>
          <li><a href="https://wa.me/264852485426">💬 WhatsApp +264 85 248 5426</a></li>
          <li><a href="tel:+264852485426">📞 Phone: +264 85 248 5426</a></li>
          <li><span style="color:#8dafc9;font-size:13px">Deliveries: Thursdays 08:00–10:00 &amp; 16:00–17:00 (bulk contract clients only; all other orders pick up at agreed time once confirmed) (bulk contract clients only; all other orders pick up at agreed time once confirmed)</span></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom-bar">
      <span>© 2026 The CoolerBox Ice Hub cc. All rights reserved. Shop 14, Makalani Mall, Ongwediva.</span>
    </div>
  </footer>

  <script src="/hero-ice.js?v=2"></script>
  <script>
    const menuBtn = document.getElementById('menu-btn');
    const drawer = document.getElementById('mobile-drawer');
    if (menuBtn && drawer) {
      menuBtn.addEventListener('click', () => {
        const isOpen = drawer.classList.toggle('open');
        menuBtn.setAttribute('aria-expanded', String(isOpen));
        menuBtn.textContent = isOpen ? '✕' : '☰';
      });
      drawer.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
          drawer.classList.remove('open');
          menuBtn.setAttribute('aria-expanded', 'false');
          menuBtn.textContent = '☰';
        });
      });
    }
    const mapIframe = document.getElementById('hub-map-iframe');
    const mapStatus = document.getElementById('hub-map-status');
    if (mapIframe && mapStatus) {
      let mapLoaded = false;
      mapIframe.addEventListener('load', () => { mapLoaded = true; });
      setTimeout(() => {
        if (!mapLoaded) {
          mapStatus.textContent = 'Map preview timed out on your connection. Use Get Directions below to open Makalani Mall, Ongwediva.';
          mapIframe.style.display = 'none';
        }
      }, 4500);
    }
  </script>
</body>
</html>