<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#0b2b5b">
  <title>Contact Us | The CoolerBox Ice Hub — Ongwediva, Namibia</title>
  <meta name="description"
    content="Contact The CoolerBox Ice Hub. Message info@coolerboxicehub.com directly for pure ice, bottled water supply, event packages, and commercial deliveries in Ongwediva.">
  <link rel="icon" type="image/jpeg" href="/assets/logo-symbol-blue.jpeg">
  <link rel="stylesheet" href="/ice-company.css">
</head>

<body>
  <!-- Top Bar -->
  <div class="site-top-bar">
    <div class="site-top-inner">
      <div class="top-bar-location">
        <span>📍 Makalani Mall · Ongwediva, Namibia</span>
      </div>
      <div class="top-bar-contact">
        <a href="mailto:info@coolerboxicehub.com">✉ info@coolerboxicehub.com</a>
        <a href="https://wa.me/264852485426" target="_blank" rel="noopener">💬 WhatsApp +264 85 248 5426</a>
      </div>
    </div>
  </div>

  <!-- Header -->
  <header class="site-header">
    <div class="site-nav-container">
      <a class="site-brand" href="/" aria-label="CoolerBox Ice Hub Home">
        <img src="/assets/logo-primary.jpeg" alt="The CoolerBox — Ice, Water, Refreshment">
      </a>
      <ul class="site-nav-menu">
        <li><a class="site-nav-link" href="/">Home</a></li>
        <li><a class="site-nav-link" href="/products">Products</a></li>
        <li><a class="site-nav-link" href="/services">Business & Events</a></li>        <li><a class="site-nav-link active" href="/contact">Contact</a></li>
        <li><a class="site-nav-link" href="/order?product=ice">Express</a></li>
      </ul>
      <a class="btn-header-order" href="/order">Order Now ↗</a>
      <button class="mobile-menu-toggle" id="menu-btn" aria-label="Toggle navigation">☰</button>
    </div>
    <div class="mobile-drawer" id="mobile-drawer">
      <a href="/">Home</a>
      <a href="/products">Products</a>
      <a href="/services">Business & Events</a>      <a class="active" href="/contact">Contact</a>
      <a href="/order?product=ice">Express</a>
      <a href="/order" style="color:var(--cb-cyan);font-weight:700">Order Now ↗</a>
    </div>
  </header>

  <!-- Banner -->
  <section class="page-title-banner">
    <div class="page-title-inner">
      <span class="page-title-tag">DIRECT COMMUNICATION</span>
      <h1>Contact CoolerBox Ice Hub</h1>
      <p>Have questions, need an official quote, or want to arrange recurring commercial ice or water delivery? Reach our team directly below.</p>
    </div>
  </section>

  <!-- Main Content -->
  <main class="content-section">
    <div class="contact-screen-grid">
      <!-- Contact Details -->
      <div class="contact-info-panel">
        <h2>Get in Touch</h2>
        <p class="intro">Whether you need emergency party ice, event bottled water, or contracted commercial distribution, we are ready to assist.</p>

        <div class="contact-item-group">
          <div class="contact-item-row">
            <div class="contact-item-icon">✉</div>
            <div>
              <h4>Official Email</h4>
              <p><a href="mailto:info@coolerboxicehub.com?subject=Enquiry%20via%20CoolerBox%20Website">info@coolerboxicehub.com</a></p>
            </div>
          </div>

          <div class="contact-item-row">
            <div class="contact-item-icon">💬</div>
            <div>
              <h4>WhatsApp Hotline</h4>
              <p><a href="https://wa.me/264852485426" target="_blank" rel="noopener">+264 85 248 5426</a></p>
            </div>
          </div>

          <div class="contact-item-row">
            <div class="contact-item-icon">📞</div>
            <div>
              <h4>Telephone</h4>
              <p><a href="tel:+264852485426">+264 85 248 5426</a></p>
            </div>
          </div>

          <div class="contact-item-row">
            <div class="contact-item-icon">📍</div>
            <div>
              <h4>Physical Hub</h4>
              <p>Shop 14, Makalani Mall<br>Main Road, Ongwediva, Namibia</p>
            </div>
          </div>

          <div class="contact-item-row">
            <div class="contact-item-icon">🕒</div>
            <div>
              <h4>Operating Hours</h4>
              <p>Monday – Saturday: 08:00 – 18:00<br>Sunday & Public Holidays: 09:00 – 15:00</p>
            </div>
          </div>
        </div>

        <div style="display:flex;flex-wrap:wrap;gap:12px">
          <a class="btn-hero-primary" href="mailto:info@coolerboxicehub.com?subject=CoolerBox%20Enquiry&body=Product%3A%20%0AQuantity%3A%20%0APreferred%20Date%3A%20%0ACollection%20or%20Delivery%3A%20%0ANotes%3A%20" style="padding:12px 22px;font-size:14px">
            Email Us ✉
          </a>
          <a class="btn-hero-outline" href="https://wa.me/264852485426" target="_blank" rel="noopener" style="padding:12px 22px;font-size:14px">
            WhatsApp Chat ↗
          </a>
          <a class="btn-hero-outline" href="https://maps.google.com/?q=Makalani+Mall+Ongwediva+Namibia" target="_blank" rel="noopener" style="padding:12px 22px;font-size:14px">
            Get Directions ↗
          </a>
        </div>
      </div>

      <!-- Direct Message Form -->
      <div class="contact-form-panel">
        <h3>Send Us a Direct Message</h3>
        <p class="sub">Your message is sent directly to <strong>info@coolerboxicehub.com</strong>. You will receive an immediate confirmation reference.</p>

        <form id="contact-form">
          <div class="form-group-row">
            <div class="form-field-unit">
              <label for="contact-name">Your Full Name *</label>
              <input type="text" id="contact-name" name="name" placeholder="e.g. Maria Shikongo" required>
            </div>
            <div class="form-field-unit">
              <label for="contact-phone">Phone / WhatsApp *</label>
              <input type="tel" id="contact-phone" name="phone" placeholder="e.g. +264 81 234 5678" required>
            </div>
          </div>

          <div class="form-field-unit">
            <label for="contact-email">Your Email Address *</label>
            <input type="email" id="contact-email" name="email" placeholder="e.g. yourname@domain.com" required>
          </div>

          <div class="form-field-unit">
            <label for="contact-subject">Subject</label>
            <select id="contact-subject" name="subject">
              <option value="General Enquiry">General Enquiry</option>
              <option value="Custom Event Branding & Labelled Water">Custom Event Branding &amp; Labelled Water</option>
              <option value="Purified Ice Supply Quote">Purified Ice Supply Quote</option>
              <option value="Bottled Water for Event / Occasion">Bottled Water for Event / Occasion</option>
              <option value="Bulk Retail & Business Supply">Bulk Retail &amp; Business Supply</option>
              <option value="Retail & Outlet Partnership">Retail &amp; Outlet Partnership</option>
              <option value="Other">Other</option>
            </select>
            <div id="branding-enquiry" style="margin-top:8px;padding:12px;border-radius:10px;background:#edf6fa;border:1px solid #cce3f2;font-size:13px;color:#0b3861" hidden>
              <strong>Custom Event Branding:</strong> Please include your bottle size (330 ml or 500 ml), quantity (min. 50 bottles), event date, and label wording/theme. Proof approval &amp; required payment start the 48–72 hour production clock.
              <div style="margin-top:10px">
                <label for="contact-design-file" style="display:block;font-weight:700;margin-bottom:4px">Upload Design / Artwork File (optional — all design extensions)</label>
                <input type="file" id="contact-design-file" accept=".png,.jpg,.jpeg,.webp,.gif,.svg,.pdf,.ai,.eps,.psd,.cdr,.tiff,.tif,.zip,image/*,application/pdf" style="width:100%;font-size:13px">
                <small style="display:block;margin-top:4px;color:#47606f">Accepted: PNG, JPG, WebP, GIF, SVG, PDF, AI, EPS, PSD, CDR, TIFF, ZIP (max 10 MB).</small>
              </div>
            </div>
          </div>

          <div class="form-field-unit">
            <label for="contact-message">Message Details *</label>
            <textarea id="contact-message" name="message" rows="5" placeholder="Tell us your product requirements, event dates, quantities or any questions..." required></textarea>
          </div>

          <button type="submit" class="btn-send-message" id="submit-btn">
            Send Enquiry ✉
          </button>

          <div id="status-box" class="contact-status-box" role="status" aria-live="polite"></div>
        </form>
      </div>
    </div>
  </main>

  <!-- Global Footer -->
  <footer class="site-footer-new">
    <div class="footer-inner-grid">
      <div class="footer-col-brand">
        <img src="/assets/logo-primary.jpeg" alt="The CoolerBox Ice Hub">
        <p>Pure Ice. Everyday Water. Reliable Supply across Ongwediva & Northern Namibia.</p>
        <p style="margin-top:12px;font-size:13px;color:#8dafc9">📍 Shop 14, Makalani Mall, Ongwediva</p>
      </div>
      <div class="footer-col">
        <h4>Navigation</h4>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/products">Products</a></li>
          <li><a href="/services">Business & Events</a></li>
          <li></li>
          <li><a href="/order">Order Now</a></li>
          <li><a href="/contact">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Help & Info</h4>
        <ul>
          <li><a href="/questions">Questions & Answers</a></li>
          <li><a href="/reviews">Customer Reviews</a></li>
          <li><a href="/privacy">Privacy Notice</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Direct Contact</h4>
        <ul>
          <li><a href="mailto:info@coolerboxicehub.com">✉ info@coolerboxicehub.com</a></li>
          <li><a href="https://wa.me/264852485426">💬 WhatsApp +264 85 248 5426</a></li>
          <li><a href="tel:+264852485426">📞 Phone: +264 85 248 5426</a></li>
          <li><span style="color:#8dafc9;font-size:13px">Deliveries: Thursdays 08:00–10:00 &amp; 16:00–17:00 (bulk contract clients only; all other orders pick up at agreed time once confirmed) (bulk contract clients only; all other orders pick up at agreed time once confirmed)</span></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom-bar">
      <span>© 2026 The CoolerBox Ice Hub. All rights reserved. Makalani Mall, Ongwediva.</span>
    </div>
  </footer>

  <script>
    // Mobile menu toggle
    const menuBtn = document.getElementById('menu-btn');
    const drawer = document.getElementById('mobile-drawer');
    if (menuBtn && drawer) {
      menuBtn.addEventListener('click', () => {
        drawer.classList.toggle('open');
      });
    }

    // Direct Contact Form Handler
    const form = document.getElementById('contact-form');
    const submitBtn = document.getElementById('submit-btn');
    const statusBox = document.getElementById('status-box');
    const subjectSelect = document.getElementById('contact-subject');
    const brandingNote = document.getElementById('branding-enquiry');
    let isSending = false;

    function syncBrandingNote() {
      if (subjectSelect && brandingNote) {
        brandingNote.hidden = subjectSelect.value !== 'Custom Event Branding & Labelled Water';
      }
    }
    if (subjectSelect) {
      const urlSubject = new URLSearchParams(window.location.search).get('subject');
      if (urlSubject && Array.from(subjectSelect.options).some(o => o.value === urlSubject)) {
        subjectSelect.value = urlSubject;
      }
      syncBrandingNote();
      subjectSelect.addEventListener('change', syncBrandingNote);
    }

    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (isSending) return;
        isSending = true;
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending Enquiry…';
        statusBox.className = 'contact-status-box';
        statusBox.style.display = 'none';

        const payload = {
          name: document.getElementById('contact-name').value.trim(),
          phone: document.getElementById('contact-phone').value.trim(),
          email: document.getElementById('contact-email').value.trim(),
          subject: document.getElementById('contact-subject').value,
          message: document.getElementById('contact-message').value.trim()
        };

        try {
          const designInput = document.getElementById('contact-design-file');
          if (designInput && designInput.files && designInput.files[0]) {
            const designFile = designInput.files[0];
            if (designFile.size > 10 * 1024 * 1024) {
              throw new Error('Design file must be 10 MB or smaller.');
            }
            const fd = new FormData();
            fd.append('file', designFile);
            const upRes = await fetch('/api/artwork', { method: 'POST', body: fd });
            const upRaw = await upRes.text();
            let upData = null;
            if (upRaw) { try { upData = JSON.parse(upRaw); } catch { upData = null; } }
            if (!upRes.ok || !upData) {
              throw new Error((upData && (upData.detail || upData.error)) || 'Could not upload your design file.');
            }
            payload.message += `\n\nAttached Design File: ${designFile.name} (${upData.url || upData.filename || upData.id})`;
          }

          const res = await fetch('/api/contact', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          const raw = await res.text();
          let data = null;
          if (raw) {
            try { data = JSON.parse(raw); } catch { data = null; }
          }
          if (res.ok && data && (data.ok || data.status === 'success' || data.success)) {
            statusBox.className = 'contact-status-box success';
            statusBox.style.display = 'block';
            const ref = data.reference || 'Saved';
            const msgNote = data.message || 'Your enquiry has been saved and routed to our team for confirmation.';
            statusBox.innerHTML = `✅ <strong>Enquiry Received!</strong> Reference: <code>${ref}</code><br>${msgNote}`;
            form.reset();
            statusBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          } else {
            throw new Error((data && (data.detail || data.error)) || 'We could not submit your enquiry right now.');
          }
        } catch (err) {
          statusBox.className = 'contact-status-box error';
          statusBox.style.display = 'block';
          const mailBody = `Product / Subject: ${payload.subject}\nName: ${payload.name}\nPhone: ${payload.phone}\n\n${payload.message}`;
          statusBox.innerHTML = `⚠️ ${err.message || 'Could not submit right now.'} Your form details have been preserved — you can retry or <a href="mailto:info@coolerboxicehub.com?subject=${encodeURIComponent(payload.subject)}&body=${encodeURIComponent(mailBody)}" style="color:#00a5ef;font-weight:bold">Email Us ✉</a> / <a href="https://wa.me/264852485426" target="_blank" rel="noopener" style="color:#00a5ef;font-weight:bold">WhatsApp ↗</a>.`;
          statusBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } finally {
          isSending = false;
          submitBtn.disabled = false;
          submitBtn.textContent = 'Send Enquiry ✉';
        }
      });
    }
  </script>
</body>

</html>
